import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import Signup from "./Signup";
import Login from "./Login";
import Dashboard from "./Dashboard";

const App = () => {
    const [token, setToken] = useState("");

    return (
        <Router>
            <div style={{ textAlign: "center" }}>
                <h2>Welcome</h2>
                <nav>
                    <Link to="/signup">Signup</Link> | 
                    <Link to="/login">Login</Link> | 
                    {token && <Link to="/dashboard">Dashboard</Link>}
                </nav>
                <Routes>
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/login" element={<Login setToken={setToken} />} />
                    <Route path="/dashboard" element={<Dashboard token={token} />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;