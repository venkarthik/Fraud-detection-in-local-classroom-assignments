import React, { useState } from "react";
import axios from "axios";

const Dashboard = ({ token }) => {
    const [file, setFile] = useState(null);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleFileUpload = async () => {
        if (!file) return alert("Please select a file!");

        const formData = new FormData();
        formData.append("file", file);

        try {
            const response = await axios.post("http://localhost:5000/submit-assignment", formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "multipart/form-data"
                }
            });
            alert(response.data.message);
        } catch (error) {
            alert(error.response?.data?.error || "Assignment submission failed!");
        }
    };

    return (
        <div style={{ textAlign: "center", marginTop: "50px" }}>
            <h2>Student Dashboard</h2>
            <input type="file" onChange={handleFileChange} />
            <button onClick={handleFileUpload}>Submit Assignment</button>
        </div>
    );
};

export default Dashboard;