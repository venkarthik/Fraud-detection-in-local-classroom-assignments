const express = require("express");
const mysql = require("mysql2");  // ✅ Use mysql2 instead of mysql
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

// ✅ Secure MySQL credentials using environment variables
const db = mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASS || "yourpassword",  // Replace with actual password
    database: process.env.DB_NAME || "mydatabase"
});

// ✅ Improved error handling
db.connect(err => {
    if (err) {
        console.error("❌ Database connection failed: " + err.message);
        process.exit(1);  // Stops the server if DB connection fails
    } else {
        console.log("✅ Connected to MySQL database.");
    }
});

// ✅ Secret key for JWT authentication
const SECRET_KEY = process.env.JWT_SECRET || "your_secret_key"; 

// ✅ User Signup Route
app.post("/signup", (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);

    db.query("INSERT INTO students (name, email, password) VALUES (?, ?, ?)", 
        [name, email, hashedPassword], 
        (err, result) => {
            if (err) return res.status(500).json({ error: "Signup failed" });
            res.json({ message: "User registered successfully" });
        }
    );
});

// ✅ User Login Route
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    db.query("SELECT * FROM students WHERE email = ?", [email], (err, results) => {
        if (err || results.length === 0) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        const user = results[0];
        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        const token = jwt.sign({ id: user.id, email: user.email }, SECRET_KEY, { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    });
});

// ✅ Server Running on Port 5000
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});